#!/usr/bin/env python3
"""
retrieve_sources.py -- standalone retrieval for the Philosophy Tutor skill.

Queries six trusted, legal, open-access philosophy sources in parallel,
chunks and ranks the results with BM25, and prints a numbered excerpt block
plus a citation list ready to paste into a prompt.

This is a standalone port of the retrieval pipeline from the original
FastAPI + Qwen2.5 "Philosophy Tutor" backend (rag/sources.py + rag/retriever.py).
The model-serving and web-server parts were removed -- this is meant to be
run by whatever agent/model is using this skill, not hosted as a service.

Requires outbound internet access to: plato.stanford.edu, iep.utm.edu,
philpapers.org, gutendex.com, api.openalex.org, api.semanticscholar.org.
Sandboxed code-execution environments (including Claude.ai's default one)
often restrict egress to an allowlist that doesn't include these domains --
if this script fails to connect, fall back to the manual method described in
references/sources.md (web search / page-fetch against the same sources).

Usage:
    python retrieve_sources.py "Averroes theory of intellect"
    python retrieve_sources.py "Averroes theory of intellect" --sources sep,iep
    python retrieve_sources.py "Averroes theory of intellect" --json
"""
from __future__ import annotations

import argparse
import asyncio
import json
import re
import sys
from dataclasses import dataclass, field

try:
    import httpx
except ImportError:
    sys.exit("Missing dependency 'httpx'. Run: pip install -r requirements.txt")

try:
    import trafilatura
except ImportError:
    trafilatura = None  # only needed for SEP/IEP HTML extraction

try:
    from rank_bm25 import BM25Okapi
except ImportError:
    sys.exit("Missing dependency 'rank-bm25'. Run: pip install -r requirements.txt")

HEADERS = {"User-Agent": "PhilosophyTutorSkill/1.0 (educational RAG)"}
TIMEOUT = httpx.Timeout(12.0, connect=6.0)
MAX_CHARS_PER_DOC = 4000
CHUNK_SIZE = 700  # characters
TOP_K = 5
MAX_CONTEXT_CHARS = 3500


@dataclass
class SourceDoc:
    title: str
    url: str
    source: str  # sep | iep | philpapers | gutenberg | openalex | semanticscholar
    text: str
    authors: list[str] = field(default_factory=list)
    year: str = ""

    def to_dict(self) -> dict:
        return {
            "title": self.title,
            "url": self.url,
            "source": self.source,
            "authors": self.authors,
            "year": self.year,
        }


def _clean(text: str, limit: int = MAX_CHARS_PER_DOC) -> str:
    text = re.sub(r"\s+", " ", text or "").strip()
    return text[:limit]


async def _fetch_text(client: httpx.AsyncClient, url: str) -> str:
    """Fetch a URL and extract readable text (HTML via trafilatura)."""
    if trafilatura is None:
        return ""
    try:
        r = await client.get(url, headers=HEADERS, follow_redirects=True)
        r.raise_for_status()
        extracted = trafilatura.extract(r.text, include_comments=False) or ""
        return _clean(extracted)
    except Exception:
        return ""


# ---------------------------------------------------------------- SEP
async def search_sep(client: httpx.AsyncClient, query: str) -> list[SourceDoc]:
    """Search the Stanford Encyclopedia of Philosophy and fetch top entries."""
    docs: list[SourceDoc] = []
    try:
        r = await client.get(
            "https://plato.stanford.edu/search/searcher.py",
            params={"query": query},
            headers=HEADERS,
        )
        r.raise_for_status()
        slugs = re.findall(r"plato\.stanford\.edu/entries/([a-z0-9\-]+)", r.text)
        seen: set[str] = set()
        for slug in slugs:
            if slug in seen:
                continue
            seen.add(slug)
            if len(seen) >= 2:
                break
        for slug in list(seen)[:2]:
            url = f"https://plato.stanford.edu/entries/{slug}/"
            text = await _fetch_text(client, url)
            if text:
                title = slug.replace("-", " ").title()
                docs.append(SourceDoc(title=f"SEP: {title}", url=url, source="sep", text=text))
    except Exception:
        pass
    return docs


# ---------------------------------------------------------------- IEP
async def search_iep(client: httpx.AsyncClient, query: str) -> list[SourceDoc]:
    """Search the Internet Encyclopedia of Philosophy (via its WordPress search)."""
    docs: list[SourceDoc] = []
    try:
        r = await client.get(
            "https://iep.utm.edu/",
            params={"s": query},
            headers=HEADERS,
            follow_redirects=True,
        )
        r.raise_for_status()
        links = re.findall(r'href="(https://iep\.utm\.edu/[a-z0-9\-]+/)"', r.text)
        seen: set[str] = set()
        for link in links:
            if link.rstrip("/").endswith(("category", "tag", "page")):
                continue
            if link in seen:
                continue
            seen.add(link)
            if len(seen) >= 1:
                break
        for url in list(seen)[:1]:
            text = await _fetch_text(client, url)
            if text:
                slug = url.rstrip("/").rsplit("/", 1)[-1]
                docs.append(
                    SourceDoc(
                        title=f"IEP: {slug.replace('-', ' ').title()}",
                        url=url,
                        source="iep",
                        text=text,
                    )
                )
    except Exception:
        pass
    return docs


# ---------------------------------------------------------------- PhilPapers
async def search_philpapers(client: httpx.AsyncClient, query: str) -> list[SourceDoc]:
    """Search PhilPapers via its public JSON search endpoint."""
    docs: list[SourceDoc] = []
    try:
        r = await client.get(
            "https://philpapers.org/s/" + httpx.QueryParams({"q": query})["q"],
            params={"format": "json"},
            headers=HEADERS,
            follow_redirects=True,
        )
        if r.status_code == 200 and r.headers.get("content-type", "").startswith("application/json"):
            data = r.json()
            entries = data.get("entries", data if isinstance(data, list) else [])
            for e in entries[:3]:
                title = e.get("title", "")
                abstract = _clean(e.get("abstract", ""), 1500)
                link = e.get("links", [e.get("url", "")])
                url = link[0] if isinstance(link, list) and link else str(link)
                if title:
                    docs.append(
                        SourceDoc(
                            title=title,
                            url=url or f"https://philpapers.org/s/{query}",
                            source="philpapers",
                            text=abstract or title,
                            authors=e.get("authors", []),
                            year=str(e.get("year", "")),
                        )
                    )
    except Exception:
        pass
    return docs


# ---------------------------------------------------------------- Gutenberg
async def search_gutenberg(client: httpx.AsyncClient, query: str) -> list[SourceDoc]:
    """Search Project Gutenberg (gutendex API) for classic philosophy texts.

    Returns plain-text UTF-8 excerpts -- the ideal machine-readable format.
    """
    docs: list[SourceDoc] = []
    try:
        r = await client.get(
            "https://gutendex.com/books",
            params={"search": query, "topic": "philosophy"},
            headers=HEADERS,
        )
        r.raise_for_status()
        results = r.json().get("results", [])[:1]
        for book in results:
            formats = book.get("formats", {})
            txt_url = (
                formats.get("text/plain; charset=utf-8")
                or formats.get("text/plain; charset=us-ascii")
                or formats.get("text/plain")
            )
            if not txt_url:
                continue
            try:
                tr = await client.get(txt_url, headers=HEADERS, follow_redirects=True)
                tr.raise_for_status()
                body = tr.text
                marker = re.search(r"\*\*\* START OF (THE|THIS) PROJECT GUTENBERG.*?\*\*\*", body)
                if marker:
                    body = body[marker.end():]
                docs.append(
                    SourceDoc(
                        title=book.get("title", "Gutenberg text"),
                        url=f"https://www.gutenberg.org/ebooks/{book.get('id', '')}",
                        source="gutenberg",
                        text=_clean(body, 3000),
                        authors=[a.get("name", "") for a in book.get("authors", [])],
                    )
                )
            except Exception:
                continue
    except Exception:
        pass
    return docs


# ---------------------------------------------------------------- OpenAlex
async def search_openalex(client: httpx.AsyncClient, query: str) -> list[SourceDoc]:
    """Search OpenAlex for open-access philosophy papers (legal Google Scholar alternative)."""
    docs: list[SourceDoc] = []
    try:
        r = await client.get(
            "https://api.openalex.org/works",
            params={
                "search": query,
                "filter": "open_access.is_oa:true,concepts.id:C138885662",  # C138885662 = Philosophy
                "per-page": 3,
            },
            headers=HEADERS,
        )
        r.raise_for_status()
        for work in r.json().get("results", [])[:3]:
            abstract = ""
            inv = work.get("abstract_inverted_index")
            if inv:
                positions: list[tuple[int, str]] = []
                for word, idxs in inv.items():
                    for i in idxs:
                        positions.append((i, word))
                abstract = " ".join(w for _, w in sorted(positions))
            oa_url = (work.get("open_access") or {}).get("oa_url") or work.get("doi") or ""
            docs.append(
                SourceDoc(
                    title=work.get("title", "Untitled"),
                    url=oa_url or f"https://openalex.org/{work.get('id', '').rsplit('/', 1)[-1]}",
                    source="openalex",
                    text=_clean(abstract, 1500) or work.get("title", ""),
                    authors=[
                        (a.get("author") or {}).get("display_name", "")
                        for a in work.get("authorships", [])[:4]
                    ],
                    year=str(work.get("publication_year", "")),
                )
            )
    except Exception:
        pass
    return docs


# ---------------------------------------------------------------- Semantic Scholar
async def search_semantic_scholar(client: httpx.AsyncClient, query: str) -> list[SourceDoc]:
    """Search Semantic Scholar Graph API (free, no key required at low volume)."""
    docs: list[SourceDoc] = []
    try:
        r = await client.get(
            "https://api.semanticscholar.org/graph/v1/paper/search",
            params={
                "query": query,
                "limit": 3,
                "fields": "title,abstract,tldr,url,year,authors,openAccessPdf",
                "fieldsOfStudy": "Philosophy",
            },
            headers=HEADERS,
        )
        r.raise_for_status()
        for p in r.json().get("data", [])[:3]:
            tldr = (p.get("tldr") or {}).get("text", "")
            abstract = p.get("abstract") or ""
            text = _clean(f"{tldr} {abstract}", 1500)
            if not text:
                continue
            oa = (p.get("openAccessPdf") or {}).get("url", "")
            docs.append(
                SourceDoc(
                    title=p.get("title", "Untitled"),
                    url=oa or p.get("url", ""),
                    source="semanticscholar",
                    text=text,
                    authors=[a.get("name", "") for a in p.get("authors", [])[:4]],
                    year=str(p.get("year", "")),
                )
            )
    except Exception:
        pass
    return docs


# ---------------------------------------------------------------- optional PDF reader
async def read_open_pdf(client: httpx.AsyncClient, url: str) -> str:
    """Extract text from an open-access PDF using PyMuPDF, if installed.

    If the PDF is scanned (no text layer) or PyMuPDF isn't installed, returns
    "" -- callers should surface the source URL to the learner instead of
    failing or guessing at the contents.
    """
    try:
        import fitz  # pymupdf
    except ImportError:
        return ""
    try:
        r = await client.get(url, headers=HEADERS, follow_redirects=True)
        r.raise_for_status()
        with fitz.open(stream=r.content, filetype="pdf") as doc:
            pages = [page.get_text() for page in doc[:10]]
        return _clean(" ".join(pages), 6000)
    except Exception:
        return ""


ALL_SOURCES = {
    "sep": search_sep,
    "iep": search_iep,
    "philpapers": search_philpapers,
    "gutenberg": search_gutenberg,
    "openalex": search_openalex,
    "semanticscholar": search_semantic_scholar,
}


async def gather_sources(query: str, enabled: list[str] | None = None) -> list[SourceDoc]:
    """Query all (or selected) sources in parallel and return merged docs."""
    names = enabled or list(ALL_SOURCES.keys())
    async with httpx.AsyncClient(timeout=TIMEOUT) as client:
        tasks = [ALL_SOURCES[n](client, query) for n in names if n in ALL_SOURCES]
        results = await asyncio.gather(*tasks, return_exceptions=True)
    docs: list[SourceDoc] = []
    for res in results:
        if isinstance(res, list):
            docs.extend(res)
    return docs


@dataclass
class RankedChunk:
    text: str
    doc: SourceDoc


def _tokenize(text: str) -> list[str]:
    return re.findall(r"[a-zA-Z\u0600-\u06FF]{2,}", text.lower())


def _chunk(doc: SourceDoc) -> list[str]:
    text = doc.text
    chunks = []
    for i in range(0, len(text), CHUNK_SIZE):
        piece = text[i : i + CHUNK_SIZE].strip()
        if len(piece) > 80:
            chunks.append(piece)
    return chunks[:6]


async def retrieve(query: str, enabled_sources: list[str] | None = None) -> tuple[str, list[dict]]:
    """Return (context_block, citations) for the given query.

    context_block: numbered excerpts ready to inject into a prompt.
    citations: list of {index, title, url, source, authors, year}.
    """
    docs = await gather_sources(query, enabled_sources)
    if not docs:
        return "", []

    corpus: list[RankedChunk] = []
    for doc in docs:
        for piece in _chunk(doc):
            corpus.append(RankedChunk(text=piece, doc=doc))

    if not corpus:
        return "", []

    bm25 = BM25Okapi([_tokenize(c.text) for c in corpus])
    scores = bm25.get_scores(_tokenize(query))
    ranked = sorted(zip(scores, range(len(corpus))), key=lambda x: -x[0])

    picked: list[RankedChunk] = []
    seen_urls: dict[str, int] = {}
    total = 0
    for score, idx in ranked:
        if len(picked) >= TOP_K or total > MAX_CONTEXT_CHARS:
            break
        chunk = corpus[idx]
        if seen_urls.get(chunk.doc.url, 0) >= 2:  # at most 2 chunks per document
            continue
        seen_urls[chunk.doc.url] = seen_urls.get(chunk.doc.url, 0) + 1
        picked.append(chunk)
        total += len(chunk.text)

    citations: list[dict] = []
    url_to_num: dict[str, int] = {}
    for chunk in picked:
        if chunk.doc.url not in url_to_num:
            url_to_num[chunk.doc.url] = len(citations) + 1
            entry = chunk.doc.to_dict()
            entry["index"] = url_to_num[chunk.doc.url]
            citations.append(entry)

    lines = []
    for chunk in picked:
        num = url_to_num[chunk.doc.url]
        lines.append(f"[{num}] {chunk.text}")

    return "\n\n".join(lines), citations


async def _main_async(args: argparse.Namespace) -> int:
    sources = args.sources.split(",") if args.sources else None
    if sources:
        unknown = [s for s in sources if s not in ALL_SOURCES]
        if unknown:
            print(f"Unknown source(s): {', '.join(unknown)}. Valid: {', '.join(ALL_SOURCES)}", file=sys.stderr)
            return 1

    context, citations = await retrieve(args.query, sources)

    if not context:
        if args.json:
            print(json.dumps({"context": "", "citations": []}, ensure_ascii=False, indent=2))
        else:
            print("No relevant excerpts found in the trusted sources for this query.")
        return 0

    if args.json:
        print(json.dumps({"context": context, "citations": citations}, ensure_ascii=False, indent=2))
    else:
        print(context)
        print("\n---\n")
        for c in citations:
            author_str = f" ({', '.join(c['authors'])})" if c.get("authors") else ""
            year_str = f" [{c['year']}]" if c.get("year") else ""
            print(f"[{c['index']}] {c['title']}{author_str}{year_str} -- {c['url']}")

    return 0


def main() -> None:
    parser = argparse.ArgumentParser(
        description="Retrieve numbered, cited excerpts from trusted philosophy sources."
    )
    parser.add_argument("query", help="The learner's question, or a compact search query derived from it")
    parser.add_argument(
        "--sources",
        help=f"Comma-separated subset of: {', '.join(ALL_SOURCES)} (default: all)",
        default=None,
    )
    parser.add_argument("--json", action="store_true", help="Print machine-readable JSON instead of formatted text")
    args = parser.parse_args()
    sys.exit(asyncio.run(_main_async(args)))


if __name__ == "__main__":
    main()
