# Philosophy Tutor -- Skill

This folder packages the "Philosophy Tutor" chatbot (originally a FastAPI + Qwen2.5 backend on Hugging Face Spaces) as a portable **Agent Skill**: the persona, citation discipline, trusted-source list, and four teaching modes, expressed as instructions any capable model can follow -- not tied to one hosted backend or one model.

## What changed from the original folder

Kept, and converted into `SKILL.md` + `references/`:
- The tutor persona and citation rules (from `app.py`'s `SYSTEM_AR` / `SYSTEM_EN`)
- The trusted-source list and retrieval approach (from `rag/sources.py`, `rag/retriever.py`)
- The four teaching modes -- Socratic dialogue, define, compare, summarize (from `skills/*.md`)

Left out, since a skill is consumed directly by a model rather than run as a service:
- `app.py`'s FastAPI app, SSE streaming, and the `/health` `/skills` `/sources` `/chat` endpoints
- The Qwen2.5 model-loading code and `Dockerfile` (Hugging Face Spaces deployment)
- `skills_loader.py`'s YAML-frontmatter parsing -- no longer needed, since a model reads the reference files directly instead of a Python loader parsing them at server startup

Your original folder and Hugging Face Space are unaffected by any of this -- this is a new, complementary package, not a replacement. If you still want the hosted Space (e.g. for a standalone web UI backed by Qwen2.5), keep running it as-is.

## Using it with Claude

- **Claude.ai / Claude Code / Cowork**: upload `philosophy-tutor.skill` (skills upload flow in Settings, or the equivalent in Claude Code). It's a plain zip -- if the `.skill` extension causes trouble anywhere, just rename it to `.zip`.
- Once installed, Claude reads `SKILL.md` automatically when a philosophy question comes up, and opens the relevant file under `references/` only when needed.

## Using it with other models (GPT, Gemini, Qwen, etc.)

Nothing here is Claude-specific -- `SKILL.md` and the `references/*.md` files are plain Markdown instructions. To use them elsewhere:

1. Paste the contents of `SKILL.md` into the model's system prompt / custom instructions field.
2. Either paste the `references/*.md` files in alongside it, or keep them on hand and paste the relevant one in when a specific mode (Socratic, define, compare, summarize) comes up.
3. For live source retrieval, either let the model use its own browsing/search tool against the sources in `references/sources.md`, or run `scripts/retrieve_sources.py` yourself and paste its output into the conversation as context.

## Running the retrieval script directly

```bash
pip install -r scripts/requirements.txt
python scripts/retrieve_sources.py "Averroes theory of intellect"
python scripts/retrieve_sources.py "Averroes theory of intellect" --sources sep,philpapers
python scripts/retrieve_sources.py "Averroes theory of intellect" --json
```

It needs outbound internet access to plato.stanford.edu, iep.utm.edu, philpapers.org, gutendex.com, api.openalex.org, and api.semanticscholar.org. Claude.ai's own code execution environment restricts outbound network access to an allowlist that doesn't include these domains, so the script won't run there -- it's meant for a local machine, a server, or any sandbox with open internet. It's also genuinely optional: the manual method in `references/sources.md` covers the same ground with a browsing tool, which is what Claude (or another model) will fall back to automatically per `SKILL.md`.

## Folder structure

```
philosophy-tutor/
├── SKILL.md                    -- entry point: persona, workflow, citation rules
├── README.md                   -- this file
├── references/
│   ├── sources.md               -- the six trusted sources: how to search/fetch each, why not Google Scholar
│   ├── socratic.md               -- Socratic dialogue mode template
│   ├── define.md                  -- three-level term definition mode template
│   ├── compare.md                  -- philosopher/school comparison mode template
│   └── summarize.md                -- argument/text summarization mode template
└── scripts/
    ├── retrieve_sources.py          -- standalone CLI port of the original RAG pipeline
    └── requirements.txt
```
