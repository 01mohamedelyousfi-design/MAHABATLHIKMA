# Trusted sources

Six free, legal sources, chosen because they're either peer-reviewed or open-access. All six can be reached with a browsing tool (web search + page fetch) or with `scripts/retrieve_sources.py` if code execution with outbound internet access is available.

**Why these six, and not Google Scholar:** scraping Google Scholar violates its terms of service. OpenAlex and Semantic Scholar cover the same contemporary open-access literature legally, so there's no need to scrape it.

## Query-crafting tip (important for Arabic questions)

SEP, IEP, PhilPapers, OpenAlex, and Semantic Scholar are all English-language databases. A search in Arabic will usually return nothing, even for well-covered topics. Translate or transliterate the core concept or name into English before searching:

- "ابن رشد" -> search "Averroes" or "Ibn Rushd"
- "الكندي" -> search "Al-Kindi"
- "اللذة عند أبيقور" -> search "Epicurus pleasure hedonism"

Project Gutenberg is the exception if you're looking for a philosopher's own words in translation -- search by the English form of their name there too, but the point is to retrieve primary text, not a summary.

## 1. Stanford Encyclopedia of Philosophy (SEP)

Peer-reviewed; the gold standard for a rigorous overview of a concept, philosopher, or argument.

- Search: `https://plato.stanford.edu/search/searcher.py?query=<query>` (or web_search "<query> stanford encyclopedia of philosophy")
- Entries live at `https://plato.stanford.edu/entries/<slug>/` -- fetch the page and read the relevant section(s); entries are long, so don't pull the whole thing.
- Take 1-2 entries per question.

## 2. Internet Encyclopedia of Philosophy (IEP)

Also peer-reviewed; a good second opinion alongside or instead of SEP, especially for entries SEP doesn't cover.

- Search: `https://iep.utm.edu/?s=<query>` (or web_search "<query> iep.utm.edu")
- Skip category/tag/pagination links; fetch the actual article page.

## 3. PhilPapers

The broadest index of academic philosophy papers -- useful for what the contemporary literature says about a topic, and for author bibliographies.

- JSON search: `https://philpapers.org/s/<query>?format=json` returns entries with `title`, `abstract`, `authors`, `year`, and a link.
- If JSON isn't reachable with your tools, web_search "<query> philpapers" and fetch the top result page instead.

## 4. Project Gutenberg (via the gutendex API)

Full public-domain primary texts -- use this when the learner wants the philosopher's own words, not a secondary summary.

- Search: `https://gutendex.com/books?search=<query>&topic=philosophy` returns JSON with a `formats` map; use the `text/plain; charset=utf-8` link when present.
- The raw text file has a Project Gutenberg boilerplate header -- skip past the "*** START OF ... PROJECT GUTENBERG ***" marker to reach the actual text.
- Coverage is mostly European/English-language classics (Plato, Aristotle, Descartes, Kant, Mill, etc., in translation) -- don't assume it holds non-Western primary sources.

## 5. OpenAlex

Open-access contemporary papers, filterable to philosophy -- the legal alternative to scraping Google Scholar.

- `https://api.openalex.org/works?search=<query>&filter=open_access.is_oa:true,concepts.id:C138885662` (C138885662 is OpenAlex's Philosophy concept ID).
- Abstracts come back as an "inverted index" (word -> positions); reconstruct the plain-text abstract by sorting positions before reading it.
- Prefer the `open_access.oa_url` field for a fetchable full text; fall back to the DOI link.

## 6. Semantic Scholar

Abstracts plus short AI-generated TL;DRs -- useful for a fast read on what a paper argues.

- `https://api.semanticscholar.org/graph/v1/paper/search?query=<query>&fields=title,abstract,tldr,url,year,authors,openAccessPdf&fieldsOfStudy=Philosophy`
- The `tldr.text` field is often enough on its own; add the abstract if you need more depth.

## General retrieval principles

- 1-2 excerpts per source, a few hundred words each -- enough to support a specific claim, not the whole document.
- Prefer source diversity: if SEP and IEP both cover the same ground, one citation from each beats two from the same one.
- If a source can't be read (e.g. a scanned PDF with no text layer), surface the link to the learner rather than failing silently or guessing at its contents.
- Never invent a title, author, or URL. If you're not confident a fetched page is really the source in question, say so rather than citing it confidently.
