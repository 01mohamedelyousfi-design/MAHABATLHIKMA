# Prompts لتوليد الصور — مُكيّفة من NotebookLM لـ z-ai

ملف `notebooklm_slide_prompts.md` الأصلي (المرفق من المستخدم) كُتب لـ Nano Banana Pro من Google. بيئتنا تستخدم z-ai-web-dev-sdk مع نموذج صور مختلف. هذا الملف يُكيّف **المبادئ** (لا الحرفية) لتعمل مع نموذجنا.

---

## مبادئ عامة (مأخوذة من NotebookLM، تعمل في أي نموذج)

1. **اِسمِع مرجعًا بصريًا**: "في أسلوب Apple keynote" أفضل من "أنيق وحديث". النماذج تعرف الأساليب الشهيرة.
2. **اِذكر نوع النص**: "اِرسم النص مباشرة داخل الصورة كنص واضح" — مهم للصور التعليمية.
3. **اِحدد المواد والإضاءة**: "زجاج مُصنفر"، "سيراميك مطفي"، "إضاءة اتجاهية ناعمة"، "خلفية استوديو" — ترفع الواقعية.
4. **اِستخدم أرقامًا لا صفات**: "8 وحدات"، "5 خطوات"، "3 بطاقات" بدل "عدة".
5. **اِضبط النسبة**: 16:9 للعرض، 9:16 للطولي، 1:1 للتوازن.
6. **للعربية**: اِذكر "نص عربي" صراحة، وأضف "دعم الخطوط العربية" — النموذج يحتاج التلميح.
7. **كرّر المراجع البصرية**: لو الصورة جزء من سلسلة، اِذكر "بنفس أسلوب الصورة السابقة".
8. **لا تطلب وجوهًا بشرية**: استخدم رموزًا، أشياء، مناظر، أشكال هندسية.

---

## أنماط الصور المُستخدمة في المهارة

### 1. صورة سياق الإشكالية (القسم 1 من الطور 1)

**الهدف**: صورة رمزية تطرح الإشكالية الفلسفية بصراحة.

**النمط المُفضّل**: Sketchnote Whiteboard (مأخوذ من NotebookLM §7) — مناسب للتعليم، يدعم العربية، يبدو يدويًا ودافئًا.

**Prompt مُكيّف**:
```
Create a sketch-note style illustration representing the philosophical
concept of [CONCEPT]. Hand-drawn marker style, slightly imperfect lines,
hand-drawn arrows connecting ideas. Use a few marker colors: black for
structure, blue for emphasis, red for tension/conflict, green for
resolution. Off-white background with subtle paper texture. Use simple
boxes, circles, and arrows to draw the conceptual diagram. Include
[2-3 KEY ARABIC WORDS] as labels rendered directly in the image in
clear Arabic typography. No human faces. Composition should feel like
a thoughtful whiteboard sketch in a philosophy seminar.
```

**متى تُستخدم**: لكل أنواع المواضيع الفلسفية في MVP.

---

### 2. صورة المخطط البصري (بديل للصورة في v1.0)

**الهدف**: مخطط يُظهر بنية المشكلة المنطقية.

**الأدوات المُستخدمة**: 
- **Mermaid** (للمخططات المنطقية، البنية الشجرية، خطوط الزمن)
- **Matplotlib** (للجداول البصرية، المقارنات الكمية)

لا تستخدم image-generation لهذه الحالة — استخدم كود Mermaid مباشرة في HTML.

**أمثلة كود Mermaid**:

```mermaid
graph LR
    A[الإشكالية] --> B[الموقف 1]
    A --> C[الموقف 2]
    A --> D[الموقف 3]
    B --> E{الخلاصة}
    C --> E
    D --> E
```

```mermaid
timeline
    title خط زمني لتطور مفهوم الحرية
    350 ق.م : أفلاطون — الحرية كمعرفة
    300 ق.م : أرسطو — الحرية كفعل اختياري
    1632    : سبينوزا — الحرية كضرورة مفهومة
    1789    : كانط — الحرية كاستقلال أخلاقي
```

---

### 3. صور قصة الطور 1 (اختياري، v1.0)

**الهدف**: صورة تُعبّر عن قصة المتعلّم المُتخيلة.

**Prompt مُكيّف** (Storyboard style، مأخوذ من NotebookLM §9):
```
Create a pencil-sketch style storyboard frame illustrating a scene
about [SCENE DESCRIPTION]. 16:9 aspect ratio, light watercolor washes.
Cinematic composition: rule of thirds, leading lines. Muted color
palette: greys, blues, warm ambers. The scene shows [OBJECTS/ELEMENTS]
without human faces — use silhouettes, hands only, or objects as
substitutes. Render a short Arabic caption at the bottom: "[CAPTION]"
in clear Arabic typography. Style reference: cinematic storyboard.
```

---

## أنماط مُستبعَدة من هذه المهارة

هذه الأنماط من ملف NotebookLM الأصلي **لا تُستخدم** في المهارة:

- **Bento Grid / Glassmorphism** (§4, §5) — جمالية منتج تقني، لا تليق بالفلسفة
- **McKinsey / VC Pitch** (§2.2, §2.3) — أدوات استشارية تجارية
- **Manga** (§8) — جمالية يابانية قد لا تناسب النص الفلسفي العربي
- **Steve Jobs minimalist** (§2.1) — عرض تقديمي، لا صفحة درس

---

## إعدادات z-ai image-generation

عند استدعاء `image-generation` عبر z-ai-web-dev-sdk:

```javascript
// مثال (التفاصيل في skill image-generation)
const result = await zai.images.generate({
  prompt: "<the adapted prompt above>",
  size: "1024x1024",  // أو "1792x1024" لـ 16:9
});
```

**قواعد**:
- حجم افتراضي: `1024x1024` (مربّع، يناسب الصور الرمزية)
- حجم بديل: `1792x1024` (16:9، يناسب لوحات العرض)
- احفظ الناتج في `/home/z/my-project/download/assets/<topic>_<section>.png`
- اِضغط الصورة إن زادت عن 500KB (استخدم Pillow في Python)

---

## تدقّيق ذاتي للـ Prompt

قبل إرسال الـ prompt، تحقّق:
- [ ] ذكرت الموضوع الفلسفي صراحة
- [ ] ذكرت "Arabic" و "Arabic typography" إن كنت تريد نصًا عربيًا
- [ ] ذكرت "no human faces"
- [ ] ذكرت نسبة العرض (مربع/أفقي)
- [ ] اِستخدمت مرجعًا بصريًا معروفًا (sketchnote, storyboard...)
- [ ] طول الـ prompt < 400 كلمة (الطول المُفرط يُضعف التركيز)

---

## بديل عند فشل توليد الصورة

إن فشل `image-generation` أو أعطى نتيجة غير مرضية:
1. أعد المحاولة مرة واحدة فقط (لا تكرر أكثر)
2. إن فشلت الثانية، اِستخدم **Mermaid diagram** كبديل (دائمًا ينجح)
3. إن كان الموضوع مجردًا جدًا (مثل "الوجود")، اِستخدم سؤالًا مكتوبًا كبيرًا بدل صورة

الأهم: لا تُعلّق الدرس كله على نجاح صورة واحدة. الصورة عُنصر مساعد، لا جوهر.
