---
name: aflatoon
description: "How to build a personalized interactive philosophy lesson in Arabic (RTL) that turns an abstract philosophical question into a lived experience tailored to the learner's own interests (programming, art, sports, music, biology, etc.). Use this skill whenever the user wants to LEARN or TEACH philosophy, build a philosophy lesson, explore a philosophical problem (freedom, justice, consciousness, identity, truth, ethics, etc.), explain a philosopher's opinion, practice philosophical argumentation (الحجاج), or create interactive educational content for philosophy. Trigger this skill also when the user mentions: درس فلسفي، إشكالية، حجاج، دعوى، بينة، مجيز، تدريس الفلسفة, or wants to connect philosophy to their personal field of interest. The skill produces a single self-contained HTML file (RTL Arabic) with 4 phases: (0) brief interview, (1) building the philosophical problem via the learner's interests, (2) three philosophers' opinions with color-coded argumentation, (3) comparative conclusion. Always use this skill for philosophy teaching/learning requests, even if the user does not explicitly ask for a 'lesson' — if the intent is philosophical education, this is the skill."
---

# أفلاطون — باني الدروس الفلسفية المُخصّصة

## الغاية من المهارة

تحويل سؤال فلسفي مُجرّد إلى درس تفاعلي يعيشه المتعلّم عبر اهتماماته الخاصة. لا نُقدّم الفلسفة كمحتوى جاهز يُحفظ، بل ندفع المتعلّم لاكتشاف الإشكالية عبر وسيطه المُحبّ (برمجة، فن، رياضة، موسيقى، أحياء...)، ثم نُقدّم له مواقف الفلاسفة كـ"عدّة حجاج" يفحص بها الأقوال، ثم نطلبه أن يتأمّل الخلاصة بنفسه.

## المخرج النهائي

ملف HTML واحد قائم بذاته (self-contained): RTL عربي، Tailwind عبر CDN، vanilla JS للتفاعل، يُحفظ في `/home/z/my-project/download/aflatoon_<topic>.html`. يحتوي الأطوار الأربعة في صفحة واحدة بتنقّل داخلي عبر tabs/scroll.

## العمارة (4 أطوار + وحدة مرجعية)

```
الطور 0 (مقابلة 3 أسئلة) → الطور 1 (بناء الإشكالية) → الطور 2 (آراء الفلاسفة) → الطور 3 (الخلاصة)
                                                                                      ▲
                                                            وحدة المرجع — عدّة الحجاج (تُفتح من زر "أدوات")
```

## سير العمل المُختصر

1. **المقابلة**: اطرح 3 أسئلة موجّهة (الموضوع؟ اهتماماتك؟ مستواك؟). أكّد فهمك قبل البدء.
2. **البحث العميق**: استخدم `web-search` لفهم الإشكالية الفلسفية للموضوع.
3. **بناء الطور 1**: اختر لكل قسم نوع المحتوى الأنسب (MVP: صورة/قصة/لعبة القطار).
4. **بناء الطور 2**: ابحث عن 3 فلاسفة تناولوا الإشكالية، استخرج نصًا قصيرًا لكل واحد، لوّنه حسب أركان الحجاج.
5. **بناء الطور 3**: اِبنِ جدولًا مقارنًا + تمرين "مواقف أنت" مع سقالة مهيكلة.
6. **التجميع**: اِملأ `ui_template.html` بالمحتوى المُولّد، احفظه في `/home/z/my-project/download/`.
7. **التبليغ**: أخبر المستخدم بالمسار + ملخّص سريع لما بنيت.

## الملفات المرجعية (اِقرأها قبل البناء)

قبل البدء في بناء أي درس، اِقرأ هذه الملفات بالترتيب:

| الملف | متى تقرأه | دوره |
|------|----------|------|
| `workflow.md` | **دائمًا أولًا** | سير العمل التفصيلي خطوة بخطوة لكل طور |
| `argumentation_reference.md` | قبل بناء وحدة المرجع | النواة الثابتة لعدّة الحجاج (من Architecture of Thought) |
| `highlight_protocol.md` | قبل بناء الطور 2 | قواعد تلوين عناصر الحجاج (دعوى/مقدمات/بينة/مجيز) |
| `image_prompts.md` | قبل توليد الصور في الطور 1 | prompts مُكيّفة من NotebookLM لـ z-ai image-generation |
| `philosopher_search.md` | قبل بناء الطور 2 | بروتوكول البحث الأكاديمي عن الفلاسفة + استخراج النصوص |

## قوالب جاهزة (استخدمها مباشرة)

| المسار |用途 |
|--------|------|
| `ui_template.html` | قالب الصفحة الواحدة (RTL, Tailwind CDN). اِنسخه، اِملأه، احفظه في download/. |
| `game_templates/trolley_problem.html` | قالب لعبة مشكلة القطار. اِملأ النصوص المُعلّمة بـ `__PLACEHOLDER__`. |
| `game_templates/ship_of_theseus.html` | قالب سفينة ثيسيوس (v1.0) |
| `game_templates/prisoners_dilemma.html` | قالب معضلة السجين (v1.0) |
| `game_templates/marys_room.html` | قالب غرفة ماري (v1.0) |
| `game_templates/platos_cave.html` | قالب كهف أفلاطون (v1.0) |

## نظام التلوين (الطور 2 — آراء الفلاسفة)

| العنصر | اللون | Hex | التعريف |
|--------|------|-----|---------|
| الدعوى | أحمر | `#E53935` | الفكرة الرئيسية التي يدّعيها الفيلسوف |
| المقدمات/الاستدلال | أزرق | `#1E88E5` | الأفكار التي يبني عليها الدعوى |
| البينة | أخضر | `#43A047` | الأدلة العقلية/النقلية الداعمة |
| المجيز | ذهبي | `#B7791F` | الرابط المنطقي بين المقدمات والدعوى |

اِقرأ `highlight_protocol.md` للتعمق في القواعد.

## اللوحة اللونية للواجهة

- الخلفية: `#F5F1E8` (كريمي فلسفي)
- النص الرئيسي: `#1F1F1F`
- العنوان الرئيسي: `#0F4C5C` (أكسيد أزرق غامق)
- اللون المُميِّز: `#E36414` (برتقالي ترابي)
- حدود البطاقات: `#D4CFC4`

## معايير الجودة (تحقّق منها قبل التسليم)

- [ ] كل فيلسوف مُرفق بمصدر أكاديمي واحد على الأقل (كتاب/مقال)
- [ ] العربية فصحى معاصرة، مصطلحات فلسفية معرّبة بدقّة، RTL كامل
- [ ] الأطوار الثلاثة تخدم نفس الإشكالية ظاهريًا
- [ ] كل عنصر في طور 1 يربط الموضوع الفلسفي باهتمام المستخدم بشكل ملموس
- [ ] المخرج متجاوب مع الموبايل، ألوان فاحصة لعمى الألوان
- [ ] اللعبة تحمّل < 2 ثانية، الصور < 500KB
- [ ] وحدة المرجع قابلة للفتح من زر "أدوات" في كل طور

## ما يجب تجنّبه

- **لا تُقدّم الإجابة الفلسفية جاهزة** — اِدفع المتعلّم للتفكير، لا تقتل السؤال.
- **لا تستخدم اللهجة العامية** — فصحى معاصرة فقط (إلا في الأمثلة الحوارية الضرورية داخل القصص).
- **لا تخلط الأطوار** — كل طور له صفحته/قسمه الخاص.
- **لا تستخدم NotebookLM/Gemini مباشرة** — بيئتنا تستخدم z-ai-web-dev-sdk. ملف `image_prompts.md` يُكيّف مبادئ الـ prompts لتناسب نموذجنا.
- **لا تُولّد صورًا للأشخاص** (وجوه) — استخدم الرموز والمجازات البصرية والمناظر.
- **لا تكتب "نهاية الدرس" أو علامات اختتام اصطناعية** — اِنتهِ طبيعيًا بالمحتوى الأخير.

## عند الشك

اِقرأ `workflow.md` — كل التفاصيل هناك. إذا استمر الشك، اسأل المستخدم بدل أن تُخمّن.
