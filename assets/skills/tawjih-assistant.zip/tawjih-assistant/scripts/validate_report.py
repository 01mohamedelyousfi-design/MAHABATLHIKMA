#!/usr/bin/env python3
"""
validate_report.py — Structural + safety validation for a finished tawjih-assistant
report, before it's delivered to the student.

Checks (see report_template.md for the authoritative format this enforces):
  1. All 10 mandatory Arabic section headings are present, verbatim.
  2. Section 6 (recommended paths) has between 3 and 5 recommendation blocks;
     section 7 (alternatives) has between 2 and 3.
  3. Every recommendation block in sections 6-7 carries a confidence percentage
     and an evidence line.
  4. No confidence score above 85% appears without all three phase-evidence
     markers ([مرحلة 1 ... [مرحلة 2 ... [مرحلة 3) present in its evidence line.
  5. The fixed disclaimer block appears verbatim in section 10.
  6. The banned "impossible for you" phrasing never appears anywhere.

This script only checks structure/format/safety-phrasing — it cannot judge
whether the *content* of a recommendation is actually a good fit (that's a
human-review / persona-test question, see Section 11 of the implementation
plan). A report can pass this validator and still need human judgment before
release.

Usage:
    python validate_report.py <path_to_report.md>

Exit codes: 0 = passed, 1 = failed (see printed issues), 2 = file not found.
"""

import re
import sys

REQUIRED_HEADINGS = [
    "## 1. مقدمة",
    "## 2. ملخص الشخصية",
    "## 3. البوصلة الداخلية: إيكيغاي",
    "## 4. التأمل الفلسفي",
    "## 5. نقاط القوة والتحديات",
    "## 6. المسارات الموصى بها",
    "## 7. مسارات بديلة للاستكشاف",
    "## 8. بيئة العمل والتعلم المناسبة لك",
    "## 9. خطوات عملية والتحقق من المعلومات",
    "## 10. درجات الثقة وملاحظة ختامية",
]

DISCLAIMER_BLOCK = (
    "هذا التقرير أداة استكشاف وتوجيه، وليس قرارا نهائيا. القرار الحقيقي يعود "
    "لك ولعائلتك. بخصوص المواعيد والشروط والعتبات الدقيقة، المرجع الرسمي "
    "الوحيد هو منصة مسار (Massar)، البوابات الرسمية للتسجيل بالتعليم العالي، "
    "ومستشار(ة) التوجيه التربوي بمؤسستك — وليس هذا التقرير. يمكنك دائما "
    "العودة لطرح أسئلة إضافية أو إعادة النظر في بعض إجاباتك."
)

BANNED_PHRASES = [
    "مستحيل بالنسبة لك",
    "هذا مستحيل بالنسبة",
]

CONFIDENCE_RE = re.compile(r"نسبة الثقة\s*:\s*(\d{1,3})\s*%")
EVIDENCE_LINE_RE = re.compile(r"\*\*الأدلة:\*\*\s*(.+)")
RECOMMENDATION_SPLIT_RE = re.compile(r"^###\s+", re.MULTILINE)

PHASE_MARKERS = ["[مرحلة 1", "[مرحلة 2", "[مرحلة 3"]


def extract_section(text, heading, next_heading):
    """Returns the text strictly between `heading` and `next_heading`
    (or end-of-document if next_heading is None / not found)."""
    start = text.find(heading)
    if start == -1:
        return ""
    start += len(heading)
    if next_heading:
        end = text.find(next_heading, start)
        if end == -1:
            end = len(text)
    else:
        end = len(text)
    return text[start:end]


def find_recommendation_blocks(section_text):
    """Splits a section's text on level-3 '### ' headings and returns the
    non-empty chunks (each chunk = one recommendation's full text)."""
    parts = RECOMMENDATION_SPLIT_RE.split(section_text)
    # parts[0] is anything before the first '### ' (usually empty/whitespace) — skip it.
    return [p for p in parts[1:] if p.strip()]


def validate_recommendation_block(block, section_label, index, issues):
    conf_match = CONFIDENCE_RE.search(block)
    if not conf_match:
        issues.append(f"{section_label} - التوصية رقم {index}: لا توجد نسبة ثقة بصيغة 'نسبة الثقة: NN%'.")
        return

    confidence = int(conf_match.group(1))
    if not (0 <= confidence <= 100):
        issues.append(f"{section_label} - التوصية رقم {index}: نسبة الثقة خارج المجال المسموح (0-100): {confidence}%.")

    evidence_match = EVIDENCE_LINE_RE.search(block)
    if not evidence_match:
        issues.append(f"{section_label} - التوصية رقم {index}: لا يوجد سطر أدلة بصيغة '**الأدلة:** ...'.")
        evidence_line = ""
    else:
        evidence_line = evidence_match.group(1)

    if confidence > 85:
        missing = [m for m in PHASE_MARKERS if m not in evidence_line]
        if missing:
            issues.append(
                f"{section_label} - التوصية رقم {index}: نسبة ثقة {confidence}% تتجاوز 85% "
                f"لكن وسوم الأدلة التالية غائبة: {', '.join(missing)} "
                "(القاعدة الصارمة رقم 6: لا توصية فوق 85% دون دعم من المراحل الثلاث)."
            )


def validate(text):
    issues = []

    # 1. Required headings, verbatim.
    for heading in REQUIRED_HEADINGS:
        if heading not in text:
            issues.append(f"عنوان إلزامي مفقود: '{heading}'")

    # 2 & 3 & 4. Recommendation blocks in sections 6 and 7.
    section6 = extract_section(text, "## 6. المسارات الموصى بها", "## 7. مسارات بديلة للاستكشاف")
    section7 = extract_section(text, "## 7. مسارات بديلة للاستكشاف", "## 8. بيئة العمل والتعلم المناسبة لك")

    blocks6 = find_recommendation_blocks(section6)
    blocks7 = find_recommendation_blocks(section7)

    if not (3 <= len(blocks6) <= 5):
        issues.append(f"القسم 6 يجب أن يحتوي بين 3 و5 توصيات؛ وُجد {len(blocks6)}.")
    if not (2 <= len(blocks7) <= 3):
        issues.append(f"القسم 7 يجب أن يحتوي بين 2 و3 توصيات؛ وُجد {len(blocks7)}.")

    for i, block in enumerate(blocks6, start=1):
        validate_recommendation_block(block, "القسم 6", i, issues)
    for i, block in enumerate(blocks7, start=1):
        validate_recommendation_block(block, "القسم 7", i, issues)

    # 5. Disclaimer block, verbatim, inside section 10.
    section10 = extract_section(text, "## 10. درجات الثقة وملاحظة ختامية", None)
    if DISCLAIMER_BLOCK not in section10:
        issues.append("كتلة التنبيه الثابتة غير موجودة حرفيا في القسم 10.")

    # 6. Banned phrasing, anywhere in the document.
    for phrase in BANNED_PHRASES:
        if phrase in text:
            issues.append(f"عبارة ممنوعة وُجدت في التقرير: '{phrase}' (قاعدة 'لا أبواب مغلقة').")

    return (len(issues) == 0), issues


def main():
    if len(sys.argv) != 2:
        print("الاستخدام: python validate_report.py <path_to_report.md>", file=sys.stderr)
        sys.exit(2)

    path = sys.argv[1]
    try:
        with open(path, "r", encoding="utf-8") as f:
            text = f.read()
    except FileNotFoundError:
        print(f"خطأ: لم يُعثر على الملف: {path}", file=sys.stderr)
        sys.exit(2)

    passed, issues = validate(text)

    if passed:
        print("✅ التقرير اجتاز جميع الفحوصات البنيوية.")
        sys.exit(0)
    else:
        print(f"❌ التقرير لم يجتز الفحص ({len(issues)} مشكلة):")
        for issue in issues:
            print(f"  - {issue}")
        sys.exit(1)


if __name__ == "__main__":
    main()
