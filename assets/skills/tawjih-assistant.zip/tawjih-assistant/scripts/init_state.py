#!/usr/bin/env python3
"""
init_state.py — Creates a fresh assessment_state.json for a new
tawjih-assistant session.

Run this once, at the very start of a brand-new assessment — i.e. no
assessment_state.json was found in the workspace (see the resume protocol
in SKILL.md, Section 4). Refuses to overwrite an existing file unless
--force is passed, so a slip of the command never silently destroys a
student's in-progress session.

Usage:
    python init_state.py [path_to_write] [--force]
    (defaults to ./assessment_state.json)
"""

import json
import sys
import uuid
from datetime import datetime, timezone

DEFAULT_PATH = "assessment_state.json"


def build_fresh_state():
    now = datetime.now(timezone.utc).isoformat()
    return {
        "session_id": str(uuid.uuid4()),
        "created_at": now,
        "intake": {
            "bac_type": None,
            "bac_year": None,
            "region": None,
            "approximate_strengths_subjects": [],
            "constraints_notes": None,
        },
        "phase1_personality": [],
        "phase2_ikigai": [],
        "phase3_philosophy": [],
        # Filled progressively: dimension_scores / consistency_flags / etc. by
        # score_assessment.py, then llm_synthesis by Claude per analysis_guide.md.
        "derived_profile": {},
        "progress": {
            # 0 = greeting/intake not finished yet
            # 1/2/3 = currently inside that question phase
            # 4 = all three question phases finished (checkpoint onward is
            #     tracked by the conversation itself, not this counter, since
            #     those later stages are cheap to redo on resume)
            "phase": 0,
            "questions_asked": [],
            "phases_completed": [],
            "checkpoint_passed": False,
        },
    }


def main():
    args = sys.argv[1:]
    force = "--force" in args
    positional = [a for a in args if a != "--force"]
    path = positional[0] if positional else DEFAULT_PATH

    if not force:
        try:
            with open(path, "r", encoding="utf-8") as f:
                json.load(f)
            print(f"يوجد ملف حالة سابق فعلا في {path}. لن يتم استبداله.")
            print("طبّق بروتوكول الاستئناف في SKILL.md (اعرض على الطالب المتابعة أو")
            print("إعادة البدء) بدل استدعاء هذا السكريبت مباشرة، أو أعد التشغيل مع")
            print("--force إذا كان الطالب قد اختار صراحة إعادة البدء من جديد.")
            sys.exit(1)
        except FileNotFoundError:
            pass  # No existing file -> safe to create.
        except json.JSONDecodeError:
            print(f"⚠ ملف موجود في {path} لكنه تالف (JSON غير صالح). استخدم --force لاستبداله.")
            sys.exit(1)

    state = build_fresh_state()
    with open(path, "w", encoding="utf-8") as f:
        json.dump(state, f, ensure_ascii=False, indent=2)

    print(f"تم إنشاء حالة جديدة: {path}")
    print(f"session_id: {state['session_id']}")


if __name__ == "__main__":
    main()
