#!/usr/bin/env python3
"""
score_assessment.py — Deterministic scoring for the tawjih-assistant Skill.

Reads an assessment_state.json file, computes:
  - Phase 1 personality dimension scores (bipolar/unipolar -> 0-100, categorical -> distribution)
  - Consistency flags (numeric spread within a dimension)
  - Coverage check (all 10 Phase-1 dimensions must have >=1 answered item)
  - Phase 2 Ikigai theme frequency per circle (keyword matching against a small Arabic lexicon)
  - Phase 2 practical-realism signals (risk posture, mobility) from the structured items
  - Soft coverage warnings for Ikigai circles and Phase 3 presence

...and writes the result back into the same file under `derived_profile`
(everything except `derived_profile.llm_synthesis`, which is filled separately
by Claude during the ANALYSIS phase per analysis_guide.md).

Usage:
    python score_assessment.py [path_to_assessment_state.json]
    (defaults to ./assessment_state.json if no path given)

Exit codes:
    0 = scored successfully, full Phase-1 coverage
    2 = scored what was available, but Phase-1 coverage is incomplete
        (dimension_scores for missing dimensions will be absent; see
        derived_profile.coverage.missing_dimensions and act on it before
        moving on — ask catch-up questions, then re-run this script)
    1 = hard error (file not found, malformed JSON, etc.)

No third-party dependencies — standard library only, by design (see
Section 7.1 of the implementation plan: deterministic reliability for the
parts that must be consistent).
"""

import json
import math
import sys
from datetime import datetime, timezone

# ---------------------------------------------------------------------------
# Phase 1 dimension configuration.
# This table MUST stay in sync with references/questions_phase1_personality.md —
# same question IDs, same reverse_scored flags, same choice_map values.
# ---------------------------------------------------------------------------

DIMENSION_CONFIG = {
    "introversion_extroversion": {
        "polarity": "bipolar",
        "pole_low": "ميل انطوائي",
        "pole_high": "ميل انفتاحي اجتماعي",
        "items": {
            "Q-P1-01": {"type": "choice2", "choice_map": {"a": 5, "b": 1}},
            "Q-P1-02": {"type": "choice2", "choice_map": {"a": 1, "b": 5}},
            "Q-P1-03": {"type": "choice2", "choice_map": {"a": 5, "b": 1}},
            "Q-P1-04": {"type": "choice2", "choice_map": {"a": 1, "b": 5}},
        },
    },
    "decision_making_style": {
        "polarity": "bipolar",
        "pole_low": "تحليلي متأنٍّ",
        "pole_high": "حدسي سريع",
        "items": {
            "Q-P1-05": {"type": "choice2", "choice_map": {"a": 1, "b": 5}},
            "Q-P1-06": {"type": "likert5", "reverse_scored": False},
        },
    },
    "openness_to_experience": {
        "polarity": "unipolar",
        "trait_name": "الانفتاح على التجارب الجديدة",
        "items": {
            "Q-P1-07": {"type": "likert5", "reverse_scored": False},
            "Q-P1-08": {"type": "open"},
        },
    },
    "conscientiousness": {
        "polarity": "unipolar",
        "trait_name": "الانضباط الذاتي",
        "items": {
            "Q-P1-09": {"type": "likert5", "reverse_scored": False},
            "Q-P1-10": {"type": "likert5", "reverse_scored": False},
            "Q-P1-11": {"type": "likert5", "reverse_scored": True},
        },
    },
    "learning_style": {
        "polarity": "categorical",
        "categories": ["visual", "reading_writing", "kinesthetic", "discussion"],
        "items": {
            "Q-P1-12": {"type": "choice_categorical",
                        "choice_map": {"a": "visual", "b": "reading_writing", "c": "kinesthetic", "d": "discussion"}},
            "Q-P1-13": {"type": "choice_categorical",
                        "choice_map": {"a": "visual", "b": "reading_writing", "c": "kinesthetic", "d": "discussion"}},
        },
    },
    "collaboration_vs_independent": {
        "polarity": "bipolar",
        "pole_low": "يفضل العمل المنفرد",
        "pole_high": "يفضل العمل الجماعي",
        "items": {
            "Q-P1-14": {"type": "choice2", "choice_map": {"a": 1, "b": 5}},
            "Q-P1-15": {"type": "choice2", "choice_map": {"a": 1, "b": 5}},
        },
    },
    "leadership": {
        "polarity": "unipolar",
        "trait_name": "الميل للقيادة",
        "items": {
            "Q-P1-16": {"type": "choice2", "choice_map": {"a": 5, "b": 1}},
            "Q-P1-17": {"type": "choice2", "choice_map": {"a": 5, "b": 1}},
        },
    },
    "creativity": {
        "polarity": "unipolar",
        "trait_name": "الإبداع",
        "items": {
            "Q-P1-18": {"type": "likert5", "reverse_scored": False},
            "Q-P1-19": {"type": "likert5", "reverse_scored": True},
            "Q-P1-20": {"type": "open"},
        },
    },
    "problem_solving_preference": {
        "polarity": "categorical",
        "categories": ["analytical", "intuitive", "trial_and_error"],
        "items": {
            "Q-P1-21": {"type": "choice_categorical",
                        "choice_map": {"a": "analytical", "b": "intuitive", "c": "trial_and_error"}},
            "Q-P1-22": {"type": "choice_categorical",
                        "choice_map": {"a": "analytical", "b": "intuitive", "c": "trial_and_error"}},
        },
    },
    "work_environment_preference": {
        "polarity": "categorical",
        "categories": ["office", "lab", "field", "remote", "people_facing"],
        "items": {
            "Q-P1-23": {"type": "choice_categorical",
                        "choice_map": {"a": "office", "b": "lab", "c": "field", "d": "remote", "e": "people_facing"}},
            "Q-P1-24": {"type": "choice_categorical",
                        "choice_map": {"a": "office", "b": "lab", "c": "field", "d": "remote", "e": "people_facing"}},
            "Q-P1-25": {"type": "choice_categorical",
                        "choice_map": {"a": "office", "b": "lab", "c": "field", "d": "remote", "e": "people_facing"}},
        },
    },
}

# Consistency-flag threshold: if the numeric raw values (1-5 scale, after
# reverse-score correction) within one dimension span this much or more,
# the student's answers pointed in meaningfully different directions.
CONSISTENCY_SPREAD_THRESHOLD = 3

# ---------------------------------------------------------------------------
# Phase 2 Ikigai keyword lexicon.
# Small and intentionally simple (substring match on raw Arabic text) —
# a first-pass deterministic signal for the LLM synthesis step to refine,
# not a claim of NLP precision. See analysis_guide.md Part A for how the
# LLM is expected to use (and go beyond) this signal.
# ---------------------------------------------------------------------------

IKIGAI_LEXICON = {
    "teaching": ["تدريس", "التعليم", "أستاذ", "معلم", "شرح", "التربية", "أشرح", "تعلي"],
    "health": ["الطب", "صحة", "مريض", "تمريض", "علاج", "طبيب", "طبية", "صيدلة", "مستشفى", "تداوي"],
    "engineering_tech": ["هندسة", "برمج", "تقني", "حاسوب", "إلكترون", "آلة", "تكنولوج", "رياضيات",
                         "فيزياء", "تطبيق", "معلوميات", "كود"],
    "business": ["تجارة", "أعمال", "مقاولة", "تسويق", "مشروع", "استثمار", "إدارة", "بيع", "اقتصاد", "ريادة"],
    "arts": ["الفن", "فنون", "رسم", "موسيقى", "تصميم", "إبداع", "تمثيل", "تصوير", "غناء", "كتابة قصص"],
    "public_service": ["خدمة عامة", "المجتمع", "مساعدة الناس", "تطوع", "إدارة عمومية", "خدمة عمومية", "المواطن"],
    "agriculture": ["فلاحة", "زراعة", "بيطرة", "مزرعة", "حيوانات", "الأرض"],
    "research": ["بحث علمي", "اكتشاف", "تجربة علمية", "استقصاء", "دراسة عميقة", "الأبحاث"],
    "crafts": ["حرفة", "يدوي", "نجارة", "صناعة تقليدية", "إصلاح", "أدوات", "حرف"],
    "security_law": ["أمن", "قانون", "عدالة", "شرطة", "جيش", "دفاع", "محاماة", "قضاء", "الحقوق"],
    "sports": ["رياضة", "كرة", "لياقة", "تدريب رياضي", "مباراة", "بطولة"],
    "communication_media": ["إعلام", "صحافة", "تواصل", "لغات", "ترجمة", "تقديم", "الكتابة"],
}

IKIGAI_CIRCLES = ["love", "good_at", "world_needs", "paid_for"]

# Q-P2-14 / Q-P2-15 structured choice maps (paid_for circle, practical realism).
PAID_FOR_RISK_MAP = {"a": "stability_oriented", "b": "risk_oriented", "c": "undecided"}
PAID_FOR_MOBILITY_MAP = {"a": "stay_local", "b": "relocate_domestic", "c": "open_abroad"}


def round_half_up(x):
    """Deterministic rounding (round-half-up), so fixture expectations never
    depend on Python's banker's-rounding behavior for round()."""
    return int(math.floor(x + 0.5))


def parse_answer_normalized(entry):
    """Returns (kind, value) from an 'answer_normalized' string like
    'likert:4', 'choice:a', 'open:...', or 'skipped'."""
    raw = entry.get("answer_normalized")
    if not raw or raw == "skipped":
        return ("skipped", None)
    if ":" not in raw:
        return ("unknown", raw)
    kind, _, value = raw.partition(":")
    return (kind, value)


def is_answered(entry):
    """An item counts toward coverage if it has real recorded content.
    A skip can be marked explicitly via answer_normalized == 'skipped'; the
    primary signal is otherwise answer_raw itself. This deliberately does
    NOT require answer_normalized to be present at all, because Phase-3
    items (and many Phase-2 open items) carry no normalized field in the
    schema — only answer_raw."""
    if entry.get("answer_normalized") == "skipped":
        return False
    raw = entry.get("answer_raw")
    if raw in (None, ""):
        return False
    return True


def score_phase1(phase1_entries):
    """Computes dimension_scores + consistency_flags + phase1 coverage."""
    by_id = {e["question_id"]: e for e in phase1_entries if "question_id" in e}

    dimension_scores = {}
    consistency_flags = []
    missing_dimensions = []

    for dimension, config in DIMENSION_CONFIG.items():
        polarity = config["polarity"]
        answered_any = False
        numeric_raws = []  # for bipolar/unipolar dimensions
        category_counts = {}  # for categorical dimensions
        items_used = 0

        for qid, item_cfg in config["items"].items():
            entry = by_id.get(qid)
            if entry is None or not is_answered(entry):
                continue

            answered_any = True
            items_used += 1
            kind, value = parse_answer_normalized(entry)
            item_type = item_cfg["type"]

            if item_type == "likert5":
                try:
                    raw = int(value)
                except (TypeError, ValueError):
                    continue
                if item_cfg.get("reverse_scored"):
                    raw = 6 - raw
                numeric_raws.append(raw)

            elif item_type == "choice2":
                choice_map = item_cfg["choice_map"]
                raw = choice_map.get(value)
                if raw is not None:
                    numeric_raws.append(raw)

            elif item_type == "choice_categorical":
                choice_map = item_cfg["choice_map"]
                category = choice_map.get(value)
                if category is not None:
                    category_counts[category] = category_counts.get(category, 0) + 1

            elif item_type == "open":
                # Counts toward coverage only; no numeric contribution.
                pass

        if not answered_any:
            missing_dimensions.append(dimension)
            continue

        if polarity == "categorical":
            if category_counts:
                top_count = max(category_counts.values())
                top_categories = sorted([c for c, n in category_counts.items() if n == top_count])
            else:
                top_categories = []
            dimension_scores[dimension] = {
                "polarity": "categorical",
                "distribution": category_counts,
                "top": top_categories,
                "items_used": items_used,
            }
        else:
            if numeric_raws:
                mean_raw = sum(numeric_raws) / len(numeric_raws)
                score_0_100 = round_half_up((mean_raw - 1) / 4 * 100)
                spread = max(numeric_raws) - min(numeric_raws)
                if len(numeric_raws) >= 2 and spread >= CONSISTENCY_SPREAD_THRESHOLD:
                    consistency_flags.append(f"mixed_signal_{dimension}")

                if polarity == "bipolar":
                    label = config["pole_high"] if score_0_100 > 65 else (
                        config["pole_low"] if score_0_100 < 35 else "متوازن بين الطرفين")
                else:  # unipolar
                    level = "مرتفع" if score_0_100 > 65 else ("منخفض" if score_0_100 < 35 else "متوسط")
                    label = f"{level} في {config['trait_name']}"

                dimension_scores[dimension] = {
                    "polarity": polarity,
                    "score": score_0_100,
                    "label": label,
                    "items_used": items_used,
                    "raw_items": numeric_raws,
                }
            else:
                # Only 'open' items were answered for this dimension: coverage
                # is satisfied (a reflective answer was given) but there is no
                # numeric score to report — this is expected and fine, not an error.
                dimension_scores[dimension] = {
                    "polarity": polarity,
                    "score": None,
                    "label": "لا يوجد تقدير رقمي (أُجيب فقط عن السؤال المفتوح)",
                    "items_used": items_used,
                    "raw_items": [],
                }

    return dimension_scores, consistency_flags, missing_dimensions


def extract_ikigai_themes(phase2_entries):
    """Keyword-matches open-text Ikigai answers against IKIGAI_LEXICON,
    per circle. Also pulls out the structured paid_for signals.

    Mutates each entry in phase2_entries in place, setting
    themes_extracted (per the Section 5 data-model schema) to the list of
    themes matched in *that specific answer* — in addition to returning the
    circle-level aggregated frequency used by the report/matching stage."""
    theme_frequency = {circle: {} for circle in IKIGAI_CIRCLES}
    circles_answered = set()
    risk_posture = None
    mobility = None
    family_context_provided = False

    for entry in phase2_entries:
        if not is_answered(entry):
            entry.setdefault("themes_extracted", [])
            continue
        circle = entry.get("circle")
        if circle in IKIGAI_CIRCLES:
            circles_answered.add(circle)

        qid = entry.get("question_id")
        kind, value = parse_answer_normalized(entry)

        if qid == "Q-P2-14" and kind == "choice":
            risk_posture = PAID_FOR_RISK_MAP.get(value)
            entry["themes_extracted"] = []  # structured item, not theme-matched
            continue
        if qid == "Q-P2-15" and kind == "choice":
            mobility = PAID_FOR_MOBILITY_MAP.get(value)
            entry["themes_extracted"] = []
            continue
        if qid == "Q-P2-16":
            family_context_provided = True
            # Deliberately never theme-matched, per the safety rule that this
            # answer is used for practical realism only, never trait/interest inference.
            entry["themes_extracted"] = []
            continue

        # Open-text theme matching (love/good_at/world_needs, and Q-P2-13 in paid_for).
        text = entry.get("answer_raw") or ""
        matched_themes = []
        if text and circle in IKIGAI_CIRCLES:
            for theme, keywords in IKIGAI_LEXICON.items():
                if any(kw in text for kw in keywords):
                    theme_frequency[circle][theme] = theme_frequency[circle].get(theme, 0) + 1
                    matched_themes.append(theme)
        entry["themes_extracted"] = sorted(matched_themes)

    ikigai_circle_warnings = [c for c in IKIGAI_CIRCLES if c not in circles_answered]

    return {
        "theme_frequency": theme_frequency,
        "circle_warnings": ikigai_circle_warnings,
        "practical_realism_signals": {
            "risk_posture": risk_posture,
            "mobility": mobility,
            "family_context_notes_provided": family_context_provided,
        },
    }


def check_philosophy_presence(phase3_entries):
    """Soft warning only — Phase 3 has no per-theme coverage matrix like
    Phase 1, so we just confirm *some* reflective content exists."""
    return any(is_answered(e) for e in phase3_entries)


def score_assessment(state):
    phase1 = state.get("phase1_personality", [])
    phase2 = state.get("phase2_ikigai", [])
    phase3 = state.get("phase3_philosophy", [])

    dimension_scores, consistency_flags, missing_dimensions = score_phase1(phase1)
    ikigai_result = extract_ikigai_themes(phase2)
    philosophy_present = check_philosophy_presence(phase3)

    phase1_complete = len(missing_dimensions) == 0

    derived_profile = state.get("derived_profile") or {}
    derived_profile["dimension_scores"] = dimension_scores
    derived_profile["consistency_flags"] = consistency_flags
    derived_profile["ikigai_theme_frequency"] = ikigai_result["theme_frequency"]
    derived_profile["practical_realism_signals"] = ikigai_result["practical_realism_signals"]
    derived_profile["coverage"] = {
        "phase1_complete": phase1_complete,
        "missing_dimensions": missing_dimensions,
        "ikigai_circle_warnings": ikigai_result["circle_warnings"],
        "philosophy_answered": philosophy_present,
    }
    derived_profile["scoring_status"] = "complete" if phase1_complete else "incomplete_coverage"
    derived_profile["scored_at"] = datetime.now(timezone.utc).isoformat()
    # llm_synthesis is intentionally left untouched here — Claude fills it
    # during ANALYSIS per analysis_guide.md Part A, using this scored data.

    state["derived_profile"] = derived_profile
    return state


def main():
    path = sys.argv[1] if len(sys.argv) > 1 else "assessment_state.json"

    try:
        with open(path, "r", encoding="utf-8") as f:
            state = json.load(f)
    except FileNotFoundError:
        print(f"خطأ: لم يُعثر على الملف: {path}", file=sys.stderr)
        sys.exit(1)
    except json.JSONDecodeError as e:
        print(f"خطأ: الملف ليس JSON صالحا: {e}", file=sys.stderr)
        sys.exit(1)

    state = score_assessment(state)

    with open(path, "w", encoding="utf-8") as f:
        json.dump(state, f, ensure_ascii=False, indent=2)

    dp = state["derived_profile"]
    print(f"تم التصحيح. الحالة: {dp['scoring_status']}")
    print(f"الأبعاد المصحَّحة: {len(dp['dimension_scores'])}/10")
    if dp["coverage"]["missing_dimensions"]:
        print(f"⚠ أبعاد ناقصة (تحتاج أسئلة تكميلية): {', '.join(dp['coverage']['missing_dimensions'])}")
    if dp["consistency_flags"]:
        print(f"⚠ إشارات تناقض: {', '.join(dp['consistency_flags'])}")
    if dp["coverage"]["ikigai_circle_warnings"]:
        print(f"⚠ دوائر إيكيغاي بلا إجابة: {', '.join(dp['coverage']['ikigai_circle_warnings'])}")
    if not dp["coverage"]["philosophy_answered"]:
        print("⚠ لا توجد إجابات مسجَّلة في المرحلة 3 (الفلسفة).")

    sys.exit(0 if dp["scoring_status"] == "complete" else 2)


if __name__ == "__main__":
    main()
