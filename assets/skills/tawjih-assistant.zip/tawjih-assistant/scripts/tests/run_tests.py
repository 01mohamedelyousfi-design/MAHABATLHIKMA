#!/usr/bin/env python3
"""
run_tests.py — Runs scripts/score_assessment.py against every fixture in
scripts/tests/fixtures/ and checks the output against hand-computed expected
values (dimension scores, reverse-scoring, consistency flags, coverage,
Ikigai theme frequency).

This is what Appendix A / Section 11.1 of the implementation plan calls for:
"test fixtures — 5+ synthetic assessment_state.json files with known expected
dimension scores (including reverse-scored items and consistency flags).
Must be exact."

Usage:
    python run_tests.py
(run from anywhere; paths are resolved relative to this file)
"""

import json
import subprocess
import sys
import tempfile
import os

HERE = os.path.dirname(os.path.abspath(__file__))
FIXTURES_DIR = os.path.join(HERE, "fixtures")
SCORE_SCRIPT = os.path.join(HERE, "..", "score_assessment.py")

failures = []
passed_count = 0
checked_count = 0


def check(condition, label):
    global passed_count, checked_count
    checked_count += 1
    if condition:
        passed_count += 1
    else:
        failures.append(label)


def run_scoring(fixture_filename):
    """Copies the fixture to a temp file, runs score_assessment.py on it
    (exactly as a real invocation would), returns (derived_profile, exit_code)."""
    src = os.path.join(FIXTURES_DIR, fixture_filename)
    with open(src, "r", encoding="utf-8") as f:
        original = f.read()

    with tempfile.NamedTemporaryFile(mode="w", suffix=".json", delete=False, encoding="utf-8") as tmp:
        tmp.write(original)
        tmp_path = tmp.name

    try:
        result = subprocess.run(
            [sys.executable, SCORE_SCRIPT, tmp_path],
            capture_output=True, text=True
        )
        with open(tmp_path, "r", encoding="utf-8") as f:
            state = json.load(f)
        return state["derived_profile"], result.returncode
    finally:
        os.unlink(tmp_path)


def test_fixture1():
    print("\n--- fixture1_complete_consistent ---")
    dp, exit_code = run_scoring("fixture1_complete_consistent.json")
    ds = dp["dimension_scores"]

    check(exit_code == 0, "F1: exit code 0 (complete)")
    check(dp["scoring_status"] == "complete", "F1: scoring_status == complete")
    check(dp["coverage"]["missing_dimensions"] == [], "F1: no missing dimensions")
    check(dp["consistency_flags"] == [], f"F1: no consistency flags (got {dp['consistency_flags']})")

    check(ds["introversion_extroversion"]["score"] == 100, "F1: introversion_extroversion score == 100")
    check(ds["introversion_extroversion"]["label"] == "ميل انفتاحي اجتماعي", "F1: introversion_extroversion label")
    check(ds["decision_making_style"]["score"] == 88, f"F1: decision_making_style score == 88 (got {ds['decision_making_style']['score']})")
    check(ds["openness_to_experience"]["score"] == 100, "F1: openness score == 100")
    check(ds["conscientiousness"]["score"] == 92, f"F1: conscientiousness score == 92 (got {ds['conscientiousness']['score']})")
    check(ds["conscientiousness"]["raw_items"] == [5, 4, 5], f"F1: conscientiousness raw_items reverse-corrected == [5,4,5] (got {ds['conscientiousness']['raw_items']})")
    check(ds["learning_style"]["top"] == ["discussion"], "F1: learning_style top == discussion")
    check(ds["collaboration_vs_independent"]["score"] == 100, "F1: collaboration score == 100")
    check(ds["leadership"]["score"] == 100, "F1: leadership score == 100")
    check(ds["creativity"]["score"] == 100, f"F1: creativity score == 100 (got {ds['creativity']['score']})")
    check(ds["problem_solving_preference"]["top"] == ["analytical"], "F1: problem_solving top == analytical")
    check(ds["work_environment_preference"]["top"] == ["people_facing"], "F1: work_environment top == people_facing")
    check(ds["work_environment_preference"]["distribution"] == {"people_facing": 2, "office": 1},
          f"F1: work_environment distribution (got {ds['work_environment_preference']['distribution']})")

    ikigai = dp["ikigai_theme_frequency"]
    check(ikigai["love"] == {"teaching": 1, "engineering_tech": 2, "sports": 1}, f"F1: love themes (got {ikigai['love']})")
    check(ikigai["good_at"] == {"engineering_tech": 4, "teaching": 1, "business": 1}, f"F1: good_at themes (got {ikigai['good_at']})")
    check(ikigai["world_needs"] == {"public_service": 1, "health": 2, "security_law": 1}, f"F1: world_needs themes (got {ikigai['world_needs']})")
    check(ikigai["paid_for"] == {"engineering_tech": 1, "teaching": 1}, f"F1: paid_for themes (got {ikigai['paid_for']})")
    check(dp["practical_realism_signals"]["risk_posture"] == "risk_oriented", "F1: risk_posture")
    check(dp["practical_realism_signals"]["mobility"] == "open_abroad", "F1: mobility")
    check(dp["practical_realism_signals"]["family_context_notes_provided"] is False, "F1: family context not provided (skipped)")
    check(dp["coverage"]["ikigai_circle_warnings"] == [], "F1: no ikigai circle warnings")
    check(dp["coverage"]["philosophy_answered"] is True, "F1: philosophy answered")


def test_fixture2():
    print("\n--- fixture2_reverse_and_flags ---")
    dp, exit_code = run_scoring("fixture2_reverse_and_flags.json")
    ds = dp["dimension_scores"]

    check(exit_code == 2, f"F2: exit code 2 (incomplete coverage) (got {exit_code})")
    check(dp["scoring_status"] == "incomplete_coverage", "F2: scoring_status == incomplete_coverage")
    check(dp["coverage"]["missing_dimensions"] == ["learning_style"], f"F2: missing_dimensions == [learning_style] (got {dp['coverage']['missing_dimensions']})")
    check("learning_style" not in ds, "F2: learning_style absent from dimension_scores")

    # The key reverse-scoring test: naive (unreversed) scoring would give
    # raw_items [2,1,5] -> spread 4 -> a false flag and a wrong (moderate) score.
    # Correct reverse-scoring gives [2,1,1] -> low score, no false flag.
    check(ds["conscientiousness"]["raw_items"] == [2, 1, 1], f"F2: conscientiousness reverse-corrected raw_items == [2,1,1] (got {ds['conscientiousness']['raw_items']})")
    check(ds["conscientiousness"]["score"] == 8, f"F2: conscientiousness score == 8 (got {ds['conscientiousness']['score']})")
    check(ds["conscientiousness"]["label"] == "منخفض في الانضباط الذاتي", f"F2: conscientiousness label (got {ds['conscientiousness']['label']})")

    check("mixed_signal_conscientiousness" not in dp["consistency_flags"], "F2: no false-positive flag on conscientiousness")
    check("mixed_signal_collaboration_vs_independent" in dp["consistency_flags"], f"F2: real flag on collaboration_vs_independent present (got {dp['consistency_flags']})")
    check("mixed_signal_leadership" in dp["consistency_flags"], f"F2: real flag on leadership present (got {dp['consistency_flags']})")
    check(len(dp["consistency_flags"]) == 2, f"F2: exactly 2 consistency flags (got {dp['consistency_flags']})")

    check(ds["introversion_extroversion"]["score"] == 0, "F2: introversion_extroversion score == 0 (both raw=1)")
    check(ds["introversion_extroversion"]["items_used"] == 2, "F2: introversion_extroversion items_used == 2 (2 of 4 answered)")

    check(dp["coverage"]["ikigai_circle_warnings"] == ["world_needs"], f"F2: world_needs circle warning (got {dp['coverage']['ikigai_circle_warnings']})")
    check(dp["practical_realism_signals"]["risk_posture"] == "stability_oriented", "F2: risk_posture stability_oriented")
    check(dp["practical_realism_signals"]["mobility"] == "stay_local", "F2: mobility stay_local")
    check(dp["practical_realism_signals"]["family_context_notes_provided"] is True, "F2: family context provided")
    check(dp["coverage"]["philosophy_answered"] is False, "F2: philosophy not answered")

    ikigai = dp["ikigai_theme_frequency"]
    check(ikigai["love"] == {"arts": 1}, f"F2: love themes == arts:1 only, البيانو has no match (got {ikigai['love']})")
    check(ikigai["good_at"] == {"arts": 1}, f"F2: good_at themes (got {ikigai['good_at']})")
    check(ikigai["world_needs"] == {}, f"F2: world_needs themes empty, all skipped (got {ikigai['world_needs']})")


def test_fixture3():
    print("\n--- fixture3_fresh_empty ---")
    dp, exit_code = run_scoring("fixture3_fresh_empty.json")

    check(exit_code == 2, f"F3: exit code 2 (got {exit_code})")
    check(dp["scoring_status"] == "incomplete_coverage", "F3: scoring_status == incomplete_coverage")
    check(len(dp["dimension_scores"]) == 0, f"F3: zero dimension scores (got {len(dp['dimension_scores'])})")
    check(len(dp["coverage"]["missing_dimensions"]) == 10, f"F3: all 10 dimensions missing (got {len(dp['coverage']['missing_dimensions'])})")
    check(dp["consistency_flags"] == [], "F3: no consistency flags possible on empty input")
    check(set(dp["coverage"]["ikigai_circle_warnings"]) == {"love", "good_at", "world_needs", "paid_for"},
          f"F3: all 4 ikigai circles warned (got {dp['coverage']['ikigai_circle_warnings']})")
    check(dp["coverage"]["philosophy_answered"] is False, "F3: philosophy not answered")
    check(dp["practical_realism_signals"]["risk_posture"] is None, "F3: risk_posture is None")
    check(dp["practical_realism_signals"]["family_context_notes_provided"] is False, "F3: family context false")


def test_fixture4():
    print("\n--- fixture4_open_only_dimensions ---")
    dp, exit_code = run_scoring("fixture4_open_only_dimensions.json")
    ds = dp["dimension_scores"]

    # Coverage IS satisfied (open answers count), even though there's no numeric score.
    check(exit_code == 0, f"F4: exit code 0, coverage satisfied via open-only answers (got {exit_code})")
    check(dp["scoring_status"] == "complete", "F4: scoring_status == complete")
    check(dp["coverage"]["missing_dimensions"] == [], "F4: no missing dimensions")

    check(ds["openness_to_experience"]["score"] is None, "F4: openness score is None (open-only)")
    check(ds["openness_to_experience"]["items_used"] == 1, "F4: openness items_used == 1")
    check("لا يوجد تقدير رقمي" in ds["openness_to_experience"]["label"], "F4: openness label explains no numeric score")

    check(ds["creativity"]["score"] is None, "F4: creativity score is None (open-only)")
    check(ds["creativity"]["items_used"] == 1, "F4: creativity items_used == 1")

    # Unaffected dimensions still score normally.
    check(ds["conscientiousness"]["score"] == 92, f"F4: conscientiousness unaffected == 92 (got {ds['conscientiousness']['score']})")

    ikigai = dp["ikigai_theme_frequency"]
    check(ikigai["love"] == {"teaching": 1, "sports": 1}, f"F4: love multi-theme single-answer detection (got {ikigai['love']})")
    check(ikigai["good_at"] == {"engineering_tech": 1}, f"F4: good_at themes (got {ikigai['good_at']})")
    check(ikigai["world_needs"] == {"teaching": 1}, f"F4: world_needs themes (got {ikigai['world_needs']})")


def test_fixture5():
    print("\n--- fixture5_categorical_ties ---")
    dp, exit_code = run_scoring("fixture5_categorical_ties.json")
    ds = dp["dimension_scores"]

    check(exit_code == 0, f"F5: exit code 0 (got {exit_code})")
    check(dp["scoring_status"] == "complete", "F5: scoring_status == complete")

    # The key test: a reverse-scored item CORRECTLY averaged with regular
    # items should NOT produce a false consistency flag, because the
    # student is actually consistent (all point to high conscientiousness).
    check(ds["conscientiousness"]["raw_items"] == [5, 4, 5], f"F5: conscientiousness raw_items == [5,4,5] (got {ds['conscientiousness']['raw_items']})")
    check(ds["conscientiousness"]["score"] == 92, f"F5: conscientiousness score == 92 (got {ds['conscientiousness']['score']})")
    check("mixed_signal_conscientiousness" not in dp["consistency_flags"],
          f"F5: reverse-scoring prevents a false flag here (got {dp['consistency_flags']})")
    check(dp["consistency_flags"] == [], f"F5: no flags at all in this internally-consistent profile (got {dp['consistency_flags']})")

    # Categorical ties -> alphabetically sorted `top` list.
    check(ds["learning_style"]["top"] == ["reading_writing", "visual"], f"F5: learning_style tie sorted (got {ds['learning_style']['top']})")
    check(ds["work_environment_preference"]["top"] == ["field", "lab", "office"], f"F5: work_environment 3-way tie sorted (got {ds['work_environment_preference']['top']})")
    check(ds["problem_solving_preference"]["top"] == ["trial_and_error"], "F5: problem_solving top == trial_and_error")

    check(ds["introversion_extroversion"]["score"] == 0, "F5: introversion_extroversion score == 0")
    check(ds["introversion_extroversion"]["label"] == "ميل انطوائي", "F5: introversion label")

    ikigai = dp["ikigai_theme_frequency"]
    check(ikigai["love"] == {"health": 1, "agriculture": 1}, f"F5: love themes (got {ikigai['love']})")
    check(ikigai["paid_for"] == {"business": 1, "agriculture": 1}, f"F5: paid_for themes (got {ikigai['paid_for']})")
    check(dp["practical_realism_signals"]["risk_posture"] == "undecided", "F5: risk_posture undecided")
    check(dp["practical_realism_signals"]["mobility"] == "relocate_domestic", "F5: mobility relocate_domestic")


def main():
    test_fixture1()
    test_fixture2()
    test_fixture3()
    test_fixture4()
    test_fixture5()

    print(f"\n{'='*60}")
    print(f"النتيجة: {passed_count}/{checked_count} فحصا ناجحا")
    if failures:
        print(f"\n❌ {len(failures)} فحصا فاشلا:")
        for f in failures:
            print(f"  - {f}")
        sys.exit(1)
    else:
        print("✅ كل الفحوصات ناجحة.")
        sys.exit(0)


if __name__ == "__main__":
    main()
