#!/usr/bin/env python3
"""
run_report_validator_tests.py — Runs scripts/validate_report.py against the
two sample reports in fixtures/ (one well-formed, one deliberately flawed)
and checks it passes/fails exactly as expected, catching each planted defect.

Usage:
    python run_report_validator_tests.py
"""

import os
import subprocess
import sys

HERE = os.path.dirname(os.path.abspath(__file__))
FIXTURES_DIR = os.path.join(HERE, "fixtures")
VALIDATOR_SCRIPT = os.path.join(HERE, "..", "validate_report.py")

failures = []
passed_count = 0
checked_count = 0


def check(condition, label):
    global passed_count, checked_count
    checked_count += 1
    if condition:
        passed_count += 1
    else:
        failures.append(label)


def run_validator(filename):
    path = os.path.join(FIXTURES_DIR, filename)
    result = subprocess.run(
        [sys.executable, VALIDATOR_SCRIPT, path],
        capture_output=True, text=True
    )
    return result.returncode, result.stdout


def test_good_report():
    print("\n--- sample_report_good.md ---")
    exit_code, output = run_validator("sample_report_good.md")
    print(output)
    check(exit_code == 0, f"GOOD: exit code 0 (got {exit_code})")
    check("✅" in output, "GOOD: success marker printed")


def test_bad_report():
    print("\n--- sample_report_bad.md ---")
    exit_code, output = run_validator("sample_report_bad.md")
    print(output)
    check(exit_code == 1, f"BAD: exit code 1 (got {exit_code})")
    check("## 4. التأمل الفلسفي" in output, "BAD: caught the renamed/missing heading")
    check("90" in output and "85" in output, "BAD: caught the >85% confidence without full evidence")
    check("القسم 6" in output and ("3" in output and "5" in output), "BAD: caught wrong recommendation count in section 6")
    check("القسم 7" in output, "BAD: caught wrong recommendation count in section 7")
    check("مستحيل بالنسبة لك" in output, "BAD: caught the banned 'impossible for you' phrase")
    check("كتلة التنبيه" in output, "BAD: caught the missing/incomplete disclaimer block")


def main():
    test_good_report()
    test_bad_report()

    print(f"\n{'='*60}")
    print(f"النتيجة: {passed_count}/{checked_count} فحصا ناجحا")
    if failures:
        print(f"\n❌ {len(failures)} فحصا فاشلا:")
        for f in failures:
            print(f"  - {f}")
        sys.exit(1)
    else:
        print("✅ كل الفحوصات ناجحة.")
        sys.exit(0)


if __name__ == "__main__":
    main()
